/* Archery Duel — beginner-friendly 3D archery game.
   The scene is made from procedural 3D shapes, so no image assets are required. */
(() => {
  'use strict';

  const canvas = document.getElementById('renderCanvas');
  const shootButton = document.getElementById('shootButton');
  const centerAimButton = document.getElementById('centerAimButton');
  const nextRoundButton = document.getElementById('nextRoundButton');
  const playAgainButton = document.getElementById('playAgainButton');
  const loadingOverlay = document.getElementById('loadingOverlay');
  const statusMessage = document.getElementById('statusMessage');
  const sceneTip = document.getElementById('sceneTip');

  // Game settings you can adjust later.
  const ROUNDS_PER_MATCH = 3;
  const SHOTS_PER_ROUND = 3;
  const ARROW_SPEED = 29;
  const GRAVITY = 9.81;
  const PLAYER_X = -4.5;
  const COMPUTER_X = 4.5;
  const SHOOTER_Z = 7.3;
  const SHOOTER_Y = 1.65;
  const TARGET_Z = -16;
  const TARGET_PLANE_Z = -15.72;
  const TARGET_Y = 2.5;
  const TARGET_RADIUS = 2.2;
  const AIM_LIMIT_X = 3.3;
  const AIM_MIN_Y = 0.12;
  const AIM_MAX_Y = 5.3;

  let engine;
  let scene;
  let camera;
  let aimMarker;
  let playerBowString;
  let computerBowString;
  let aimPoint = { x: PLAYER_X, y: TARGET_Y };
  let isAnimating = false;
  let turn = 'player';
  let currentRound = 1;
  let playerRoundScores = [];
  let computerRoundScores = [];
  let playerTotal = 0;
  let computerTotal = 0;
  let roundFinished = false;
  let matchFinished = false;
  let roundArrows = [];
  let aiTimer = null;
  let lastPointerUpdate = 0;

  const colors = {
    grass: '#6c8c47', grassLight: '#8ea85a', forest: '#35543b', wood: '#8b5b32',
    cream: '#f1e5c5', black: '#202b2a', blue: '#2676ad', red: '#c94632', yellow: '#f6cd45',
    player: '#c2db80', playerDark: '#54754b', computer: '#ce8150', computerDark: '#784a34'
  };

  function material(name, hex, options = {}) {
    const mat = new BABYLON.StandardMaterial(name, scene);
    mat.diffuseColor = BABYLON.Color3.FromHexString(hex);
    if (options.emissive) mat.emissiveColor = BABYLON.Color3.FromHexString(options.emissive);
    if (options.specular) mat.specularColor = BABYLON.Color3.FromHexString(options.specular);
    if (options.alpha !== undefined) mat.alpha = options.alpha;
    return mat;
  }

  function makeBox(name, size, position, mat, scaling) {
    const mesh = BABYLON.MeshBuilder.CreateBox(name, { size }, scene);
    mesh.position.copyFrom(position);
    if (scaling) mesh.scaling.copyFrom(scaling);
    mesh.material = mat;
    return mesh;
  }

  function makeSphere(name, diameter, position, mat, scaling) {
    const mesh = BABYLON.MeshBuilder.CreateSphere(name, { diameter, segments: 16 }, scene);
    mesh.position.copyFrom(position);
    if (scaling) mesh.scaling.copyFrom(scaling);
    mesh.material = mat;
    return mesh;
  }

  function makeCylinder(name, diameter, height, position, mat, rotationX = 0) {
    const mesh = BABYLON.MeshBuilder.CreateCylinder(name, { diameter, height, tessellation: 16 }, scene);
    mesh.position.copyFrom(position);
    mesh.rotation.x = rotationX;
    mesh.material = mat;
    return mesh;
  }

  function cylinderBetween(name, a, b, diameter, mat) {
    // The archer's arms and legs mostly sit in the same vertical plane.
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const length = Math.sqrt(dx * dx + dy * dy);
    const mesh = BABYLON.MeshBuilder.CreateCylinder(name, { diameter, height: length, tessellation: 10 }, scene);
    mesh.position.set((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2);
    mesh.rotation.z = Math.atan2(dx, dy);
    mesh.material = mat;
    return mesh;
  }

  function buildGround() {
    const sky = new BABYLON.Color4(0.55, 0.75, 0.87, 1);
    scene.clearColor = sky;
    const groundMat = material('soft field grass', '#789552');
    groundMat.specularColor = new BABYLON.Color3(0, 0, 0);
    const ground = BABYLON.MeshBuilder.CreateGround('field', { width: 180, height: 180, subdivisions: 2 }, scene);
    ground.position.y = -0.12;
    ground.material = groundMat;

    const laneMat = material('lane grass', '#8aa25a');
    const edgeMat = material('lane edge', '#b5b879');
    [PLAYER_X, COMPUTER_X].forEach((x, index) => {
      const lane = BABYLON.MeshBuilder.CreateGround(`archery lane ${index}`, { width: 5.4, height: 25.8 }, scene);
      lane.position.set(x, -0.085, -4.4);
      lane.material = laneMat;
      // Narrow edges make the two competitors' lanes easy to read from the camera.
      [-2.72, 2.72].forEach(edgeX => {
        const strip = BABYLON.MeshBuilder.CreateGround('lane border', { width: 0.07, height: 25.8 }, scene);
        strip.position.set(x + edgeX, -0.067, -4.4);
        strip.material = edgeMat;
      });
    });

    // Rounded, distant hills create a gentle horizon without using downloaded assets.
    const hillMat1 = material('distant hill dark', '#678b65');
    const hillMat2 = material('distant hill light', '#86a575');
    for (let i = 0; i < 17; i++) {
      const x = -48 + i * 6.1;
      const z = -48 - Math.random() * 9;
      const scaleX = 4 + Math.random() * 6;
      const hill = makeSphere('far green hill', 1, new BABYLON.Vector3(x, -1.9, z), i % 2 ? hillMat1 : hillMat2,
        new BABYLON.Vector3(scaleX, 5 + Math.random() * 3, 3.5));
      hill.isPickable = false;
    }

    // Simple stylized trees along both edges of the range.
    const trunkMat = material('tree bark', '#795333');
    const leafMats = [material('deep pine', '#31563c'), material('pine green', '#3e6844'), material('leaf light', '#577d49')];
    for (let side of [-1, 1]) {
      for (let i = 0; i < 11; i++) {
        const x = side * (10 + Math.random() * 7);
        const z = 10 - i * 5.1;
        const height = 2.5 + Math.random() * 1.8;
        makeCylinder('tree trunk', 0.32, height, new BABYLON.Vector3(x, height / 2 - 0.06, z), trunkMat);
        const crown = makeSphere('tree crown', 2.2 + Math.random() * 0.7,
          new BABYLON.Vector3(x, height + 0.45, z), leafMats[i % leafMats.length],
          new BABYLON.Vector3(1, 1.1 + Math.random() * 0.3, 0.9));
        crown.isPickable = false;
      }
    }

    // A few small stones and grass tufts add detail close to the lanes.
    const stoneMat = material('warm stones', '#b7b49b');
    for (let i = 0; i < 32; i++) {
      const x = (Math.random() - 0.5) * 27;
      const z = -13 + Math.random() * 32;
      if (Math.abs(x - PLAYER_X) < 3.1 || Math.abs(x - COMPUTER_X) < 3.1) continue;
      const stone = makeSphere('field stone', 0.22 + Math.random() * 0.26,
        new BABYLON.Vector3(x, 0.02, z), stoneMat, new BABYLON.Vector3(1.3, 0.45, 0.8));
      stone.isPickable = false;
    }

    // High, soft clouds made from overlapping spheres.
    const cloudMat = material('soft cloud', '#edf0e4');
    cloudMat.alpha = 0.78;
    [[-13, 13, -19], [12, 15, -25], [0, 17, -33]].forEach((set, idx) => {
      const [cx, cy, cz] = set;
      for (let j = 0; j < 4; j++) {
        const cloud = makeSphere(`cloud ${idx}`, 2.2, new BABYLON.Vector3(cx + (j - 1.5) * 1.3, cy + (j % 2) * 0.25, cz), cloudMat,
          new BABYLON.Vector3(1.25, 0.65, 0.65));
        cloud.isPickable = false;
      }
    });
  }

  function buildTarget(x, label) {
    const woodMat = material(`${label} target wood`, '#a47745');
    const standMat = material(`${label} stand`, '#6a4b30');
    const outerWhite = material(`${label} white target`, '#f4ead1');
    const black = material(`${label} black target`, '#303533');
    const blue = material(`${label} blue target`, '#2b78a7');
    const red = material(`${label} red target`, '#c64736');
    const yellow = material(`${label} bullseye`, '#f9d249', { emissive: '#33270b' });

    // Two wooden feet and a horizontal brace hold the target upright.
    makeCylinder(`${label} left support`, 0.12, 2.5, new BABYLON.Vector3(x - 1.63, 1.18, TARGET_Z - 0.24), standMat);
    makeCylinder(`${label} right support`, 0.12, 2.5, new BABYLON.Vector3(x + 1.63, 1.18, TARGET_Z - 0.24), standMat);
    const rearBrace = BABYLON.MeshBuilder.CreateBox(`${label} rear brace`, { width: 3.7, height: 0.14, depth: 0.14 }, scene);
    rearBrace.position.set(x, 1.3, TARGET_Z - 0.25);
    rearBrace.material = standMat;
    const targetFoot = BABYLON.MeshBuilder.CreateBox(`${label} target foot`, { width: 4.2, height: 0.16, depth: 0.7 }, scene);
    targetFoot.position.set(x, 0.08, TARGET_Z - 0.2);
    targetFoot.material = woodMat;

    function disc(name, radius, z, mat, height) {
      const mesh = BABYLON.MeshBuilder.CreateCylinder(name, { diameter: radius * 2, height, tessellation: 64 }, scene);
      mesh.position.set(x, TARGET_Y, z);
      mesh.rotation.x = Math.PI / 2; // Rotate the cylinder so its round face points toward the player.
      mesh.material = mat;
      mesh.isPickable = false;
      return mesh;
    }
    disc(`${label} outer target`, 2.2, TARGET_Z, outerWhite, 0.20);
    disc(`${label} black ring`, 1.82, TARGET_Z + 0.105, black, 0.06);
    disc(`${label} blue ring`, 1.43, TARGET_Z + 0.155, blue, 0.06);
    disc(`${label} red ring`, 1.04, TARGET_Z + 0.205, red, 0.06);
    disc(`${label} gold center`, 0.64, TARGET_Z + 0.255, yellow, 0.06);

    // Thin white scoring rings are drawn on the target face.
    const whiteLine = material(`${label} target lines`, '#f4ead1');
    [0.42, 0.82, 1.22, 1.62, 2.02].forEach((radius, i) => {
      const ring = BABYLON.MeshBuilder.CreateTorus(`${label} scoring ring`, { diameter: radius * 2, thickness: 0.026, tessellation: 64 }, scene);
      ring.position.set(x, TARGET_Y, TARGET_Z + 0.292);
      ring.rotation.x = Math.PI / 2;
      ring.material = whiteLine;
      ring.isPickable = false;
    });

    const labelMat = material(`${label} target name`, label === 'Player' ? '#d8ef97' : '#f6c080', { emissive: label === 'Player' ? '#243311' : '#3a210b' });
    const namePlane = BABYLON.MeshBuilder.CreatePlane(`${label} lane sign`, { width: 1.65, height: 0.42 }, scene);
    namePlane.position.set(x, 5.15, TARGET_Z + 0.2);
    namePlane.material = labelMat;
    const signText = new BABYLON.DynamicTexture(`${label} name text`, { width: 512, height: 128 }, scene, false);
    signText.hasAlpha = true;
    signText.drawText(label.toUpperCase(), null, 88, 'bold 70px Arial', label === 'Player' ? '#263815' : '#42230c', 'transparent', true);
    const signMat = new BABYLON.StandardMaterial(`${label} sign material`, scene);
    signMat.diffuseTexture = signText;
    signMat.emissiveColor = new BABYLON.Color3(1, 1, 1);
    signMat.opacityTexture = signText;
    signMat.backFaceCulling = false;
    namePlane.material = signMat;
    return { x, y: TARGET_Y, z: TARGET_PLANE_Z };
  }

  function createBow(x, y, z, bowMat, stringMat, tag) {
    // A curved tube and a string make a simple procedural bow model.
    const points = [
      new BABYLON.Vector3(x, y - 0.84, z),
      new BABYLON.Vector3(x + 0.20, y - 0.63, z),
      new BABYLON.Vector3(x + 0.33, y - 0.32, z),
      new BABYLON.Vector3(x + 0.35, y, z),
      new BABYLON.Vector3(x + 0.29, y + 0.33, z),
      new BABYLON.Vector3(x + 0.16, y + 0.64, z),
      new BABYLON.Vector3(x, y + 0.84, z)
    ];
    const bow = BABYLON.MeshBuilder.CreateTube(`${tag} bow`, { path: points, radius: 0.055, tessellation: 8 }, scene);
    bow.material = bowMat;
    const string = BABYLON.MeshBuilder.CreateLines(`${tag} bowstring`, {
      points: [new BABYLON.Vector3(x, y - 0.84, z + 0.025), new BABYLON.Vector3(x, y + 0.84, z + 0.025)]
    }, scene);
    string.color = BABYLON.Color3.FromHexString(stringMat);
    return string;
  }

  function buildArcher(x, z, shirtHex, trousersHex, isComputer) {
    const shirt = material(isComputer ? 'computer tunic' : 'player tunic', shirtHex);
    const trouser = material(isComputer ? 'computer trousers' : 'player trousers', trousersHex);
    const skin = material(isComputer ? 'computer skin' : 'player skin', '#bd8c68');
    const hair = material(isComputer ? 'computer hair' : 'player hair', '#322c25');
    const leather = material(isComputer ? 'computer leather' : 'player leather', '#60442f');
    const boot = material(isComputer ? 'computer boots' : 'player boots', '#302d25');
    const armZ = z - 0.02;

    // Legs and boots.
    makeCylinder('left trouser leg', 0.22, 0.8, new BABYLON.Vector3(x - 0.18, 0.56, z), trouser);
    makeCylinder('right trouser leg', 0.22, 0.8, new BABYLON.Vector3(x + 0.18, 0.56, z), trouser);
    makeBox('left boot', 0.32, new BABYLON.Vector3(x - 0.18, 0.12, z + 0.1), boot, new BABYLON.Vector3(1, 0.65, 1.25));
    makeBox('right boot', 0.32, new BABYLON.Vector3(x + 0.18, 0.12, z + 0.1), boot, new BABYLON.Vector3(1, 0.65, 1.25));

    // Torso, shoulders, neck and head.
    makeSphere('archer hips', 0.67, new BABYLON.Vector3(x, 1.0, z), trouser, new BABYLON.Vector3(0.82, 0.65, 0.7));
    makeSphere('archer torso', 0.92, new BABYLON.Vector3(x, 1.48, z - 0.025), shirt, new BABYLON.Vector3(0.68, 1.0, 0.53));
    makeCylinder('archer neck', 0.19, 0.22, new BABYLON.Vector3(x, 1.94, z), skin);
    makeSphere('archer head', 0.54, new BABYLON.Vector3(x, 2.2, z - 0.02), skin, new BABYLON.Vector3(0.86, 1.08, 0.9));
    makeSphere('archer hair', 0.5, new BABYLON.Vector3(x, 2.37, z + 0.005), hair, new BABYLON.Vector3(0.95, 0.58, 0.9));

    // A small leather quiver on the back and a few visible arrow shafts.
    makeCylinder('quiver', 0.26, 0.88, new BABYLON.Vector3(x - 0.31, 1.75, z + 0.28), leather, 0.18);
    for (let i = 0; i < 3; i++) {
      const arrow = makeCylinder('quiver arrow', 0.035, 0.8, new BABYLON.Vector3(x - 0.39 + i * 0.08, 2.22, z + 0.28), material('quiver wood', '#d0b57a'));
      arrow.rotation.z = -0.08;
    }

    // Arms are made from joined cylinders; the bow sits at chest height.
    cylinderBetween('left upper arm', { x: x - 0.27, y: 1.72, z: armZ }, { x: x - 0.53, y: 1.49, z: armZ }, 0.16, shirt);
    makeSphere('left hand', 0.19, new BABYLON.Vector3(x - 0.54, 1.47, armZ - 0.02), skin);
    cylinderBetween('right upper arm', { x: x + 0.27, y: 1.72, z: armZ }, { x: x + 0.48, y: 1.5, z: armZ }, 0.16, shirt);
    cylinderBetween('right forearm', { x: x + 0.48, y: 1.5, z: armZ }, { x: x + 0.22, y: 1.64, z: armZ - 0.06 }, 0.12, skin);
    makeSphere('right hand', 0.16, new BABYLON.Vector3(x + 0.22, 1.64, armZ - 0.06), skin);

    const bowMat = material(isComputer ? 'copper bow' : 'hickory bow', isComputer ? '#9d5735' : '#7c512e');
    const stringMat = isComputer ? '#f5d2a3' : '#e2ead1';
    const bowString = createBow(x - 0.52, 1.72, z - 0.14, bowMat, stringMat, isComputer ? 'computer' : 'player');
    return bowString;
  }

  function createAimMarker() {
    const markerMat = material('aim reticle', '#fff1a7', { emissive: '#e1a92d' });
    const marker = BABYLON.MeshBuilder.CreateTorus('aim ring', { diameter: 0.36, thickness: 0.035, tessellation: 32 }, scene);
    marker.rotation.x = Math.PI / 2;
    marker.material = markerMat;
    marker.position.set(PLAYER_X, TARGET_Y, TARGET_PLANE_Z + 0.055);
    marker.isPickable = false;
    const center = makeSphere('aim ring center', 0.07, new BABYLON.Vector3(PLAYER_X, TARGET_Y, TARGET_PLANE_Z + 0.055), markerMat);
    center.parent = marker;
    center.position.set(0, 0, 0.005);
    return marker;
  }

  function buildScene() {
    scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color4(0.55, 0.75, 0.87, 1);
    scene.collisionsEnabled = false;

    camera = new BABYLON.FreeCamera('range camera', new BABYLON.Vector3(0, 10.8, 29), scene);
    camera.setTarget(new BABYLON.Vector3(0, 2.0, -4.1));
    camera.fov = 0.82;
    camera.minZ = 0.1;
    camera.maxZ = 250;
    camera.inputs.clear(); // Keep the camera steady; the player controls aim, not the view.

    const hemi = new BABYLON.HemisphericLight('sky light', new BABYLON.Vector3(0.2, 1, 0.1), scene);
    hemi.intensity = 0.92;
    hemi.groundColor = BABYLON.Color3.FromHexString('#485a3d');
    const sun = new BABYLON.DirectionalLight('afternoon sun', new BABYLON.Vector3(-0.45, -1, 0.28), scene);
    sun.position = new BABYLON.Vector3(-15, 30, 20);
    sun.intensity = 0.75;

    buildGround();
    buildTarget(PLAYER_X, 'Player');
    buildTarget(COMPUTER_X, 'Computer');
    playerBowString = buildArcher(PLAYER_X, 8.6, colors.player, colors.playerDark, false);
    computerBowString = buildArcher(COMPUTER_X, 8.6, colors.computer, colors.computerDark, true);
    aimMarker = createAimMarker();
    return scene;
  }

  function setStatus(message) {
    statusMessage.textContent = message;
  }

  function sumScores(scores) {
    return scores.reduce((sum, score) => sum + score, 0);
  }

  function createShotPips(id, count) {
    const pips = document.getElementById(id).querySelectorAll('i');
    pips.forEach((pip, index) => pip.classList.toggle('filled', index < count));
  }

  function updateScoreboard() {
    document.getElementById('playerRoundScore').textContent = sumScores(playerRoundScores);
    document.getElementById('computerRoundScore').textContent = sumScores(computerRoundScores);
    document.getElementById('playerTotalScore').textContent = playerTotal;
    document.getElementById('computerTotalScore').textContent = computerTotal;
    document.getElementById('playerShotText').textContent = `${playerRoundScores.length} / ${SHOTS_PER_ROUND}`;
    document.getElementById('computerShotText').textContent = `${computerRoundScores.length} / ${SHOTS_PER_ROUND}`;
    document.getElementById('playerShotsList').textContent = playerRoundScores.length ? `Scores: ${playerRoundScores.join('  ·  ')}` : 'No shots yet';
    document.getElementById('computerShotsList').textContent = computerRoundScores.length ? `Scores: ${computerRoundScores.join('  ·  ')}` : 'No shots yet';
    createShotPips('playerShotPips', playerRoundScores.length);
    createShotPips('computerShotPips', computerRoundScores.length);
    document.getElementById('roundNumber').textContent = currentRound;
    const progress = document.querySelectorAll('.round-progress i');
    progress.forEach((bar, index) => bar.classList.toggle('active', index < currentRound));
    const playerBadge = document.getElementById('playerTurnBadge');
    const computerBadge = document.getElementById('computerTurnBadge');
    playerBadge.textContent = turn === 'player' && !roundFinished && !matchFinished ? 'YOUR TURN' : 'READY';
    playerBadge.classList.toggle('muted', turn !== 'player' || roundFinished || matchFinished);
    computerBadge.textContent = turn === 'computer' && !roundFinished && !matchFinished ? 'SHOOTING' : 'WAITING';
    computerBadge.classList.toggle('computer-active', turn === 'computer' && !roundFinished && !matchFinished);
    document.getElementById('roundStatus').textContent = roundFinished ? 'Round complete' : matchFinished ? 'Match complete' : (turn === 'player' ? 'Aim carefully' : 'Computer shooting');
    shootButton.disabled = isAnimating || turn !== 'player' || roundFinished || matchFinished;
    centerAimButton.disabled = isAnimating || turn !== 'player' || roundFinished || matchFinished;
  }

  function setAimPoint(x, y) {
    aimPoint.x = Math.max(PLAYER_X - AIM_LIMIT_X, Math.min(PLAYER_X + AIM_LIMIT_X, x));
    aimPoint.y = Math.max(AIM_MIN_Y, Math.min(AIM_MAX_Y, y));
    if (aimMarker) aimMarker.position.set(aimPoint.x, aimPoint.y, TARGET_PLANE_Z + 0.055);
  }

  function aimFromPointer(event) {
    if (!scene || turn !== 'player' || isAnimating || roundFinished || matchFinished) return;
    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width * engine.getRenderWidth();
    const y = (event.clientY - rect.top) / rect.height * engine.getRenderHeight();
    const ray = scene.createPickingRay(x, y, BABYLON.Matrix.Identity(), camera);
    if (Math.abs(ray.direction.z) < 0.0001) return;
    const distance = (TARGET_PLANE_Z - ray.origin.z) / ray.direction.z;
    if (distance <= 0) return;
    const point = ray.origin.add(ray.direction.scale(distance));
    setAimPoint(point.x, point.y);
    lastPointerUpdate = performance.now();
  }

  function calculateTrajectory(fromX, toX, toY) {
    const dx = toX - fromX;
    const forwardDistance = SHOOTER_Z - TARGET_PLANE_Z;
    const horizontalDistance = Math.sqrt(dx * dx + forwardDistance * forwardDistance);
    const deltaY = toY - SHOOTER_Y;
    const v2 = ARROW_SPEED * ARROW_SPEED;
    const discriminant = Math.max(0, v2 * v2 - GRAVITY * (GRAVITY * horizontalDistance * horizontalDistance + 2 * deltaY * v2));
    const tanPitch = (v2 - Math.sqrt(discriminant)) / (GRAVITY * horizontalDistance);
    const pitch = Math.atan(tanPitch);
    const yaw = Math.atan2(dx, forwardDistance);
    const vx = ARROW_SPEED * Math.cos(pitch) * Math.sin(yaw);
    const vy = ARROW_SPEED * Math.sin(pitch);
    const vz = -ARROW_SPEED * Math.cos(pitch) * Math.cos(yaw);
    const flightTime = horizontalDistance / (ARROW_SPEED * Math.cos(pitch));
    const direction = new BABYLON.Vector3(vx, vy, vz).normalize();
    return { vx, vy, vz, flightTime, pitch, yaw, direction, horizontalDistance };
  }

  function scoreForPoint(point, centerX) {
    const distance = Math.hypot(point.x - centerX, point.y - TARGET_Y);
    if (distance <= 0.28) return 10;
    if (distance <= 0.48) return 9;
    if (distance <= 0.70) return 8;
    if (distance <= 0.95) return 7;
    if (distance <= 1.20) return 6;
    if (distance <= 1.45) return 5;
    if (distance <= 1.70) return 4;
    if (distance <= 1.90) return 3;
    if (distance <= 2.08) return 2;
    if (distance <= TARGET_RADIUS) return 1;
    return 0;
  }

  function makeFlyingArrow(isComputer, trajectory) {
    const root = new BABYLON.TransformNode(isComputer ? 'computer arrow root' : 'player arrow root', scene);
    const shaftMat = material(isComputer ? 'computer arrow wood' : 'player arrow wood', '#d2b37b');
    const tipMat = material(isComputer ? 'computer arrow tip' : 'player arrow tip', '#4e5556', { specular: '#aaaaaa' });
    const featherMat = material(isComputer ? 'computer arrow feathers' : 'player arrow feathers', isComputer ? '#f3b56a' : '#d8eaa0');
    const shaft = BABYLON.MeshBuilder.CreateCylinder('arrow shaft', { diameter: 0.035, height: 1.05, tessellation: 8 }, scene);
    shaft.parent = root;
    shaft.material = shaftMat;
    const head = BABYLON.MeshBuilder.CreateCylinder('arrow head', { diameterTop: 0, diameterBottom: 0.12, height: 0.22, tessellation: 8 }, scene);
    head.parent = root;
    head.position.y = 0.59;
    head.material = tipMat;
    const tail = BABYLON.MeshBuilder.CreateBox('arrow fletching', { width: 0.12, height: 0.18, depth: 0.022 }, scene);
    tail.parent = root;
    tail.position.y = -0.43;
    tail.material = featherMat;
    const tail2 = tail.clone('arrow fletching 2');
    tail2.parent = root;
    tail2.rotation.y = Math.PI / 2;
    root.rotation = new BABYLON.Vector3(trajectory.pitch - Math.PI / 2, -trajectory.yaw, 0);
    roundArrows.push(root);
    return root;
  }

  function animateShot(isComputer, targetPoint, done) {
    const launchX = isComputer ? COMPUTER_X : PLAYER_X;
    const trajectory = calculateTrajectory(launchX, targetPoint.x, targetPoint.y);
    const arrow = makeFlyingArrow(isComputer, trajectory);
    const start = new BABYLON.Vector3(launchX, SHOOTER_Y, SHOOTER_Z);
    const direction = trajectory.direction;
    let elapsed = 0;
    const observer = scene.onBeforeRenderObservable.add(() => {
      const dt = Math.min(engine.getDeltaTime() / 1000, 0.04);
      elapsed += dt;
      const t = Math.min(elapsed, trajectory.flightTime);
      const pos = new BABYLON.Vector3(
        start.x + trajectory.vx * t,
        start.y + trajectory.vy * t - 0.5 * GRAVITY * t * t,
        start.z + trajectory.vz * t
      );
      // The arrow mesh is centred behind its tip, along the direction of travel.
      arrow.position.copyFrom(pos.subtract(direction.scale(0.7)));
      if (elapsed >= trajectory.flightTime) {
        scene.onBeforeRenderObservable.remove(observer);
        const impact = new BABYLON.Vector3(targetPoint.x, targetPoint.y, TARGET_PLANE_Z);
        arrow.position.copyFrom(impact.subtract(direction.scale(0.7)));
        done(impact);
      }
    });
  }

  function showImpactResult(who, score) {
    if (score === 10) sceneTip.textContent = `${who}: BULLSEYE! 10 points`;
    else if (score >= 7) sceneTip.textContent = `${who}: Great shot — ${score} points`;
    else if (score > 0) sceneTip.textContent = `${who}: ${score} point${score === 1 ? '' : 's'}`;
    else sceneTip.textContent = `${who}: Miss — 0 points`;
  }

  function setTurn(nextTurn) {
    turn = nextTurn;
    updateScoreboard();
  }

  function playerShoot() {
    if (isAnimating || turn !== 'player' || roundFinished || matchFinished) return;
    isAnimating = true;
    updateScoreboard();
    setStatus('Your arrow is flying...');
    sceneTip.textContent = 'Watch your arrow — score is based on where it lands.';
    const shotPoint = { x: aimPoint.x, y: aimPoint.y };
    animateShot(false, shotPoint, impact => {
      const score = scoreForPoint(impact, PLAYER_X);
      playerRoundScores.push(score);
      playerTotal += score;
      isAnimating = false;
      showImpactResult('You', score);
      updateScoreboard();
      setTurn('computer');
      setStatus('Computer is lining up its shot...');
      sceneTip.textContent = 'The computer is taking its turn.';
      aiTimer = setTimeout(computerShoot, 850);
    });
  }

  function randomNormal() {
    // Box–Muller sampling gives the AI a natural-looking spread around the bullseye.
    let u = 0;
    let v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  function computerShoot() {
    aiTimer = null;
    if (roundFinished || matchFinished) return;
    isAnimating = true;
    updateScoreboard();
    setStatus('Computer is shooting...');
    const spread = 0.56; // Medium difficulty: usually hits the target, but not always the centre.
    const targetPoint = {
      x: Math.max(COMPUTER_X - 2.65, Math.min(COMPUTER_X + 2.65, COMPUTER_X + randomNormal() * spread)),
      y: Math.max(TARGET_Y - 2.05, Math.min(TARGET_Y + 2.05, TARGET_Y + randomNormal() * spread))
    };
    animateShot(true, targetPoint, impact => {
      const score = scoreForPoint(impact, COMPUTER_X);
      computerRoundScores.push(score);
      computerTotal += score;
      isAnimating = false;
      showImpactResult('Computer', score);
      updateScoreboard();
      if (playerRoundScores.length >= SHOTS_PER_ROUND && computerRoundScores.length >= SHOTS_PER_ROUND) {
        finishRound();
      } else {
        setTurn('player');
        setStatus('Your turn — adjust your aim and shoot.');
        sceneTip.textContent = 'Move the mouse to aim at your target, then click to shoot.';
      }
    });
  }

  function finishRound() {
    roundFinished = true;
    turn = 'none';
    updateScoreboard();
    shootButton.hidden = true;
    centerAimButton.hidden = true;
    if (currentRound < ROUNDS_PER_MATCH) {
      nextRoundButton.hidden = false;
      setStatus(`Round ${currentRound} complete. Get ready for the next round.`);
      sceneTip.textContent = `Round ${currentRound}: You ${sumScores(playerRoundScores)} — Computer ${sumScores(computerRoundScores)}.`;
    } else {
      matchFinished = true;
      playAgainButton.hidden = false;
      const message = playerTotal === computerTotal ? 'Match tied!' : playerTotal > computerTotal ? 'You win the match!' : 'Computer wins the match!';
      setStatus(`${message} Final score: ${playerTotal} – ${computerTotal}.`);
      sceneTip.textContent = `${message} Final score: You ${playerTotal} — Computer ${computerTotal}.`;
      updateScoreboard();
    }
  }

  function clearRoundArrows() {
    roundArrows.forEach(arrow => arrow.dispose(false, true));
    roundArrows = [];
  }

  function beginNextRound() {
    if (aiTimer) clearTimeout(aiTimer);
    aiTimer = null;
    clearRoundArrows();
    currentRound += 1;
    playerRoundScores = [];
    computerRoundScores = [];
    roundFinished = false;
    matchFinished = false;
    isAnimating = false;
    turn = 'player';
    setAimPoint(PLAYER_X, TARGET_Y);
    nextRoundButton.hidden = true;
    playAgainButton.hidden = true;
    shootButton.hidden = false;
    centerAimButton.hidden = false;
    sceneTip.textContent = 'New round. Aim for the gold centre to score 10 points.';
    setStatus('New round — your turn.');
    updateScoreboard();
  }

  function startNewMatch() {
    if (aiTimer) clearTimeout(aiTimer);
    aiTimer = null;
    clearRoundArrows();
    currentRound = 1;
    playerRoundScores = [];
    computerRoundScores = [];
    playerTotal = 0;
    computerTotal = 0;
    roundFinished = false;
    matchFinished = false;
    isAnimating = false;
    turn = 'player';
    setAimPoint(PLAYER_X, TARGET_Y);
    nextRoundButton.hidden = true;
    playAgainButton.hidden = true;
    shootButton.hidden = false;
    centerAimButton.hidden = false;
    sceneTip.textContent = 'Move the mouse to aim at your target, then click to shoot.';
    setStatus('New match — your turn.');
    updateScoreboard();
  }

  function resetAim() {
    if (turn !== 'player' || isAnimating || roundFinished || matchFinished) return;
    setAimPoint(PLAYER_X, TARGET_Y);
    sceneTip.textContent = 'Aim reset to the gold centre — a bullseye is worth 10 points.';
  }

  function handleKeyDown(event) {
    const key = event.key.toLowerCase();
    if (key === ' ' || key.startsWith('arrow')) event.preventDefault();
    if (key === ' ' || key === 'enter') {
      playerShoot();
      return;
    }
    if (key === 'r') {
      resetAim();
      return;
    }
    if (turn !== 'player' || isAnimating || roundFinished || matchFinished) return;
    const step = event.shiftKey ? 0.28 : 0.13;
    if (key === 'arrowleft' || key === 'a') setAimPoint(aimPoint.x - step, aimPoint.y);
    if (key === 'arrowright' || key === 'd') setAimPoint(aimPoint.x + step, aimPoint.y);
    if (key === 'arrowup' || key === 'w') setAimPoint(aimPoint.x, aimPoint.y + step);
    if (key === 'arrowdown' || key === 's') setAimPoint(aimPoint.x, aimPoint.y - step);
  }

  function showLoadingError(message) {
    loadingOverlay.classList.remove('done');
    loadingOverlay.innerHTML = `<strong>3D engine could not load</strong><span>${message}</span><span>Check your internet connection and refresh the page.</span>`;
    setStatus('The 3D game could not start.');
  }

  function start() {
    if (!window.BABYLON) {
      showLoadingError('Babylon.js was blocked or could not load.');
      return;
    }
    try {
      engine = new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: false, stencil: true, antialias: true, adaptToDeviceRatio: true });
      buildScene();
      engine.runRenderLoop(() => {
        if (scene) scene.render();
      });
      window.addEventListener('resize', () => engine.resize());
      loadingOverlay.classList.add('done');
      updateScoreboard();
      setStatus('Your turn — aim, then shoot.');
      sceneTip.textContent = 'Aim at the gold centre for 10 points. Move your mouse, then click to shoot.';
    } catch (error) {
      console.error(error);
      showLoadingError('An error occurred while creating the scene.');
    }
  }

  canvas.addEventListener('pointermove', aimFromPointer);
  canvas.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    aimFromPointer(event);
    playerShoot();
  });
  shootButton.addEventListener('click', playerShoot);
  centerAimButton.addEventListener('click', resetAim);
  nextRoundButton.addEventListener('click', beginNextRound);
  playAgainButton.addEventListener('click', startNewMatch);
  window.addEventListener('keydown', handleKeyDown);

  // Start the 3D engine after the page's controls have been wired up.
  start();
})();
