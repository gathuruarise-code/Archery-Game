# Archery Duel — Player vs Computer

A beginner-friendly 3D archery game prototype made with HTML, CSS, JavaScript and Babylon.js. The arena and characters are created from 3D shapes in code, so the project does not need image assets.

## Play on your ThinkPad

1. Download and extract `archery-duel.zip`.
2. Open the extracted `archery-duel` folder.
3. Double-click `index.html` to open it in Microsoft Edge or Chrome.
4. Keep the laptop connected to the internet because the game loads Babylon.js from its public CDN.
5. If the page shows **“3D engine could not load”**, check your connection, refresh the page, and make sure the browser is not blocking the CDN.

If double-clicking the file does not work on your computer, open a terminal in the project folder and run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser. If Python is not installed, use the GitHub Pages method below instead.

## Controls

- **Mouse:** move the pointer over the 3D scene to position the aim ring. Left-click the scene to shoot.
- **Arrow keys or W/A/S/D:** adjust the aim a little at a time.
- **Space or Enter:** shoot an arrow.
- **R:** reset the aim to the centre of your target.
- **Center aim:** button to reset your aim.

You and the computer each shoot 3 arrows per round, for 3 rounds. Bullseyes are worth 10 points; further rings are worth fewer points. The computer uses medium difficulty and has a small random aiming error.

## Publish to GitHub Pages

1. Create a new GitHub repository, for example `archery-duel`.
2. Upload `index.html`, `styles.css`, `game.js`, and `README.md` to the repository's root folder. Do not upload only the ZIP file.
3. In the repository, open **Settings → Pages**.
4. Under the build/source section, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish, then open the URL it shows. It can take a few minutes for the first deployment.

## Project files

- `index.html` — page structure and Babylon.js CDN script.
- `styles.css` — layout, scoreboard, buttons, and responsive design.
- `game.js` — the 3D scene, aiming, arrow physics, scoring, AI, and rounds.

## Current prototype limits

This is a first playable prototype. The arena and archers are 3D, but the characters use stylized procedural models rather than detailed motion-captured characters. The computer's opponent logic, ballistic aiming, and scoring are implemented locally in the browser. Sound, mobile touch controls, saved match history, and app packaging can be added after browser testing.

## Later: make an installable app

First get the browser version working and publish it. After that, the same HTML/CSS/JavaScript project can be packaged as an Android app with Capacitor and Android Studio, or made into a Progressive Web App (PWA). App packaging should come after testing the browser version so bugs are easier to find.
